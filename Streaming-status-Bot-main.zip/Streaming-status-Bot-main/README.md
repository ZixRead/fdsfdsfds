Please leave a star for upcoming update!!

**Before starting the bot, please run `npm install` to install all necessary dependencies.**  
If you encounter any issues, feel free to reach out via our [Discord server](https://discord.gg/TSdpyMMfrU).  

Youtube : https://youtu.be/ulUS2mXUqKQ

🔹 **This project is released under the MIT License.**  

<hr>
<p align="center">
  <a href="https://star-history.com/#4levy/Streaming-status-Bot&Tips-Discord/Cwelium&Date&theme=dark">
    <img src="https://api.star-history.com/svg?repos=4levy/Streaming-status-Bot&type=Date&theme=dark"">
  </a>
</p>

<hr>

![b686eca2ccd5c990e2b078d654e674b6](https://github.com/user-attachments/assets/72289d13-db47-4c78-810f-4f1cf89439fb)
