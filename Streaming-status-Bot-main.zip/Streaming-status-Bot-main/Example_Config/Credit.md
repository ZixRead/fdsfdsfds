## THESE CONFIGURATIONS ARE CREDITED TO LOYBUNG SUPPORT | [Join Here](https://discord.gg/XDPfrU4E9G)  

📌 **Join their server for more configurations!**  
📌 **All credits for the configurations go to their respective creators.**  
